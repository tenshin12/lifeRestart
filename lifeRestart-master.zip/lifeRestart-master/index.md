# Life Restart

やり直すんだ。そして、次はうまくやる。[RESTART](view/index.html)
