# lifeRestart
Game Life Restart

from [VickScarlet/lifeRestart](https://github.com/VickScarlet/lifeRestart)

~~简体中文威力加强无敌版~~

- 限制10000初始属性，不强制全部使用
- 无限刷新天赋

[Demo](https://liferestart.mocabot.cn/)
